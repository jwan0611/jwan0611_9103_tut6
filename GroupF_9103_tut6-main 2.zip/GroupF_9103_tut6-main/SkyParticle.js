
let sky_particles = [];
// Set the noise ratio of sky particles
let sky_noiseScale = 0.01;
// Set the spacing between sky particles
let sky_space = 5;
// Set the mode of sky particles
let sky_mode = 1;
// Set the height of sky particles
let sky_height;

class SkyParticle {
    constructor(x, y, c) {
      this.x = x; // The abscissa of the particle
      this.y = y; // The vertical coordinate of the particle
      // color of particles
      this.c = color(c[0], c[1], c[2]);
      this.first = true; // Is it the first particle
      this.initX = x; // initial abscissa
      this.initY = y; // Initial vertical coordinate
      this.frame = 0; // Current frame number
      if (sky_mode == 1) {
        // Choose the maximum number of frames according to the mode
        this.maxFrame = 400;
      } else {
        this.maxFrame = int(random(100, 500));
      }
    }
  
    draw() {
      noStroke();
      fill(this.c); // Set the fill color of particles
      if (this.first) {
        // If it is the first particle, draw a rectangular fixed background
        rect(this.x, this.y, sky_space, sky_space);
        this.first = false;
      } else {
        // Otherwise draw elliptical particles
        ellipse(this.x, this.y, sky_space, sky_space);
      }
    }
  
    update() {
      if (frameCount % 2 == 0) {
        // Update position every 2 frames
        let x = this.x * sky_noiseScale; // Calculate the noise value in the x direction
        let y = this.y * sky_noiseScale; // Calculate the noise value in the y direction
        // Set the noise value for the z-axis
        let z = 10000;
        this.x += noise(x, y, z) - 0.5; // Update x coordinate based on noise value
        z = 1;
        this.y += (noise(x, y, z) - 0.5) * 0.5; // Update y coordinate based on noise value
      }
      // Increased frame rate
      this.frame++;
      if (this.frame >= this.maxFrame) {
        // When the number of frames reaches the maximum number of frames, reset the particle position
        this.frame = 0; // Reset frame number to 0
        this.x = this.initX; // Reset x coordinate to initial value
        this.y = this.initY; // Reset x coordinate to initial value
      }
    }
  }
  
  function drawRandomLines(originX, originY, angle1, angle2, numLines) {
    for (let i = 0; i < numLines; i++) {  // Loop through the specified number of lines
      let angle = random(angle1, angle2); 
      let length = random(20/1024*img.height, 1500/1024*img.height); 
  
      // Calculate the end point of the line using trigonometry
      let endX = originX + length * cos(angle);
      let endY = originY + length * sin(angle);
      
      lineSegment(originX, originY, endX, endY);  // Draw the line segment
    }
  }
  