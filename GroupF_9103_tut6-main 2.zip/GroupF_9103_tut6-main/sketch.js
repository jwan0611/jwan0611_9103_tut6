let img;
let canvasSize=1;
let attForce = 0.01;
let repForce = 0.01;

let particles = [];
let personParticles=[];
let numParticle = 100;
let numSegments=100;
let boatX;
let boatY;
let boatDir;
let boatVel;
let boatAcc;
let bridgeVel;
let bridgeAcc;
let lakeMidRedVel;
let lakeMidRedAcc;
let lakeMidGreenVel;
let lakeMidGreenAcc;

let slope;
let intercept;
let legStatus;
// Define variables for the starting point and end points of the line segments
let originX;
let originY;
let line1EndX;
let line1EndY;
let line2EndX;
let line2EndY;
let angle1;
let angle2;
let lineWidth;
let numLines;
let personCount;


function preload() {
	img = loadImage('assets/Edvard_Munch_The_Scream.jpeg');
  pic = loadImage('assets/The_Scream_Figure.png');
}

function setup() {
  imageResize();
	strokeWeight(5/500*img.width);//the size of ever particle
	background(0);//black background
  lakeSetup();
  sky_height=img.height*0.32;
  skySetup();
	boatVel = createVector(0, 0);
  boatAcc = createVector(0, 0);
  bridgeSetup();
  frameRate(30);
}

function imageResize(){
  if((windowWidth/windowHeight)>(810/1024)){
    createCanvas(windowHeight/1024*810, windowHeight);
    img.resize(windowHeight/1024*810, windowHeight);
    pic.resize(windowHeight/1024*810, windowHeight);

  }else{
    createCanvas(windowWidth, windowWidth/810*1024);
    img.resize(windowWidth, windowWidth/810*1024);
    pic.resize(windowWidth, windowWidth/810*1024);
  }
}

function draw() {
  easing();
  //draw sky
  skyDraw();
	//update the position of each particle each frame
	for (let p of particles) {
		p.move();
		p.display();
	}
  //draw boat
  boat(boatX,boatY);
  drawBridgePeople();
}

function windowResized() {
  imageResize();
  sky_height=img.height*0.32;
  skyReSetup();
  //clear the canvas
  clearParticle();
  //redraw the particle
  lakeSetup();
  boatRestart()
  bridgeSetup();
}

function clearParticle() {
  particles = [];
  personParticles = [];
}

//sky
function skySetup() {
  img.loadPixels();

  for (let x = 0; x < img.width; x += sky_space) {
    // Traverse the canvas width and step based on the spacing between sky particles
    for (let y = 0; y < sky_height; y += sky_space) {
      // Traverse the height of the sky particles and step based on the spacing between the sky particles
      const i = 4 * (y * img.width + x); // Calculate the index value of the current pixel
      // Get the color value of a pixel
      const c = [
        img.pixels[i],
        img.pixels[i + 1],
        img.pixels[i + 2],
      ];

      // Create a sky particle object
      let particle = new SkyParticle(x, y, c);
      // Add the sky particle object to the array
      sky_particles.push(particle);
    }
  }
  push();
  //sky background
  fill(233,197,111);
  rect(0,0,img.width,sky_height);
  pop();
}

function skyReSetup() {
  img.loadPixels();
//clear the primary sky particle
  for (let x = 0; x < img.width; x += sky_space) {
    for (let y = 0; y < sky_height; y += sky_space) {
      sky_particles.pop();
    }
  }
  img.loadPixels();
//redraw the particle
  for (let x = 0; x < img.width; x += sky_space) {
    // Traverse the canvas width and step based on the spacing between sky particles
    for (let y = 0; y < sky_height; y += sky_space) {
      // Traverse the height of the sky particles and step based on the spacing between the sky particles
      const i = 4 * (y * img.width + x); // Calculate the index value of the current pixel
      // Get the color value of a pixel
      const c = [
        img.pixels[i],
        img.pixels[i + 1],
        img.pixels[i + 2],
      ];
      // Create a sky particle object
      let particle = new SkyParticle(x, y, c);
      // Add the sky particle object to the array
      sky_particles.push(particle);
    }
  }
}

function skyDraw() {
  for (let p of sky_particles) {
    // Traverse sky particle array
    p.update();
    p.draw();
  }
}

function lineSegment(x1, y1, x2, y2) {
  let d = dist(x1, y1, x2, y2); // Calculate the distance between the start and end points of the line
  let start = 0; 
  // Continue drawing line segments until the full line is drawn
  while (start < d) { 
    let segLength = random(10/1024*img.height, 20/1024*img.height); 
    // Calculate the interpolation ratios for segment start and end points
    let a = start / d;
    let b = (start + segLength) / d;
    // Interpolate to find the start and end points of the segment
    let startX = lerp(x1, x2, a);
    let startY = lerp(y1, y2, a);
    let endX = lerp(x1, x2, b);
    let endY = lerp(y1, y2, b);
    // Calculate the midpoint X,Y coordinate for color sampling
    let midX = (startX + endX) / 2; 
    let midY = (startY + endY) / 2; 
    // Sample the color from the background image at the midpoint and set opacity
    let col = img.get(midX, midY);
    col[3] = 150; 
    stroke(col); 
    line(startX, startY, endX, endY);
    // Increment the start position for the next segment
    start += segLength; 
  }
}

function bridgeSetup(){
  bridgeVel=createVector(79/81, 1);
  bridgeAcc=createVector(0, 0);

  lakeMidRedVel=1;
  lakeMidRedAcc=0;
  lakeMidGreenVel=1;
  lakeMidGreenAcc=0;

//bridge&2 small people
  slope = (600 - 380) / (100 - 0);
  intercept = 380/1024*img.height;
  personCount=0;
  legStatus=0;
}

function drawBridgePeople(){
  //bridge&2 people
  originX = 0;
  originY = 380/1024*img.height;
  line1EndX = img.width;
  line1EndY = 870/1024*img.height;
  line2EndX = 0;
  line2EndY = img.height;
  angle1 = atan2(line1EndY - originY, line1EndX - originX);
  angle2 = atan2(line2EndY - originY, line2EndX - originX);
  
  lineWidth = 8/810*img.width;  // Set the line width for the random lines
  numLines = 600;  // Set the number of random lines to draw
  push();
  strokeWeight(lineWidth); 
  drawRandomLines(originX, originY, angle1, angle2, numLines); 

  // Calculate the x based on frameCount and the corresponding y
  //let x = (frameCount % 100);
  let personX = (personCount % 100);
  let personY = slope * personX + intercept;
  
  // Draw the people, positions change over time with the frameCount
  drawPeople(personX, personY);
  pop();

   // front person
   for (let p of personParticles) {
    p.move();
  }
  drawEyesMouth()
}

function easing(){
  //Draw a black rectangle with an opacity of 20 to create the trail effect on each frame
	fill(0, 20);
	noStroke();
	rect(0, sky_height, img.width, img.height);
  //ease of sky
  push();
  fill(233,197,111,1);
  rect(0,0,img.width,sky_height);
  pop();
  //ease of boat
  push();
  fill(0,20);
  rect(boatX-10,boatY-10,20,20);
  pop();
}

function drawPeople(x, y) {
  // Scale between 0.8 and 2 as y goes from 380 to 600
  let scaleFactor = map(y, 350/1024*img.height, 1800/1024*img.height, 1/810*img.height, 20/810*img.height); 
  push();
  translate(x, y);  // Translate to the position where the people will be drawn
  scale(scaleFactor);  // Apply the scaling
  noStroke();
  // Set fill color and draw ellipses for the first person
  fill(108, 92, 59);
  ellipse(0, -30/1024*img.height, 10/810*img.width, 12/1024*img.height);
  ellipse(0, -5/1024*img.height, 20/810*img.width, 45/1024*img.height);
  //draw legs and make it move
  stroke(108, 92, 59);
  strokeWeight(2/810*img.width);
  if(legStatus==0){
   //Make the legs longer in front and shorter in back, according to the principle of nearly big, round and small
    line(-2/810*img.width,17/1024*img.height,-2/810*img.width,35/1024*img.height);
    line(2/810*img.width,17/1024*img.height,2/810*img.width,39/1024*img.height);
    stroke(48, 58, 68);
    line(8/810*img.width,33/1024*img.height,8/810*img.width,50/1024*img.height);
    line(12/810*img.width,33/1024*img.height,12/810*img.width,54/1024*img.height);
    legStatus++;
  }else{
    line(-2/810*img.width,17/1024*img.height,-5/810*img.width,35/1024*img.height);
    line(2/810*img.width,17/1024*img.height,5/810*img.width,39/1024*img.height);
    stroke(48, 58, 68);
    line(8/810*img.width,33/1024*img.height,5/810*img.width,50/1024*img.height);
    line(12/810*img.width,33/1024*img.height,15/810*img.width,54/1024*img.height);
    legStatus=0;
  }
  noStroke();
  // Set a different fill color and draw ellipses for the second person
  fill(48, 58, 68);
  ellipse(10/810*img.width, -10/1024*img.height, 10/810*img.width, 12/1024*img.height);
  ellipse(10/810*img.width, 15/1024*img.height, 20/810*img.width, 45/1024*img.height);
  pop();
  personCount++;
  if(personCount>400){
    personCount=0;
  }
}


// // press the button to play and stop the music 
// function mousePressed() {
//   if (isPressed) {
//     audio.pause()
//     isPressed = false
//   }
//   else {
//     isPressed = true
//     audio.loop()
//   }
// }