

function boat(x,y){
      //raddom create a new boat
  boatX=random(img.width);
  boatY=random(0.5*img.height);
  boatDir=0;
  //make sure the position of boat is in the lake
  if((boatX*40/81+30/81*img.height)<boatY){
    boatY=boatX*40/81+30/81*img.height;
  }
  else if(boatY<28/81*img.height){
    boatY=28/81*img.height;
  }
    let bX=x;
    let bY=y;
    //use semicircle, rectangle, line to form a boat
    push();
    fill(255);
    stroke(255);
    strokeWeight(1);
    arc(bX,bY,20,8,0*PI,1*PI,OPEN);
    line(bX,bY,bX,bY-7);
    noStroke();
    fill(255,255,255);
    rect(bX,bY-7,5,2);
    pop();
    //make sure boat move in the blue lake
    if((boatX*40/81+30/81*img.height)<boatY){
      boatAcc.y=-0.2;
      boatY=boatY+20/1024*img.height;
    }
    else if(boatY<28/81*img.height){
      boatVel.add(0,2);
      boatY=boatY+boatVel.y;
      boatAcc.add(random(-0.1,0.1),random(-0.1,0.1));
      boatAcc.limit(0.5);
      boatVel.add(boatAcc);
      boatVel.limit(2);//make sure the speed of the boat not too fast
    }else if(boatDir==1){
      boatX--;
      boatY--;
    }else{
      // make boat move randomly, and add ease effect
      boatAcc.add(random(-0.1,0.1),random(-0.1,0.1));
      boatAcc.limit(0.5);
      boatVel.add(boatAcc);
      boatVel.limit(2);//make sure the speed of the boat not too fast
      boatX=boatX+boatVel.x;
      boatY=boatY+boatVel.y;
    if(boatX>=img.width){
      boatDir=1;
    }else if(boatX<=0){
      boatX=boatX+20/810*img.width;
      boatVel.add(2,0);
      boatDir=0;
      boatAcc.add(0.1,0);
      boatAcc.limit(0.5);
      boatVel.add(boatAcc);
      boatVel.limit(2);//make sure the speed of the boat not too fast
  
    }}
  }

  function boatRestart(){
    //raddom create a new boat
    boatX=random(img.width);
    boatY=random(0.5*img.height);
    boatDir=0;
    //make sure the position of boat is in the lake
    if((boatX*40/81+30/81*img.height)<boatY){
      boatY=boatX*40/81+30/81*img.height;
    }
    else if(boatY<28/81*img.height){
      boatY=28/81*img.height;
  }
 }