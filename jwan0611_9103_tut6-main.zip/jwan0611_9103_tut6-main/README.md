# jche7275_9103_tut6
## Introduction
My part is Random Seed so there is no User Input.
But I want you know that the color of sky and the lake center will change randomly and subtlety within certain limits.
Besides, the white boat will move randomly in lake.
Furthermore, the shape of sky particles and lake particles will change randomly, too. 
In addition, the emotion of the front person will change randomly.
Anyway, have fun!