//particles of lake
class Particle {
	constructor(x, y) {
    this.x = x;
    this.y = y;
		this.pos = createVector(x, y);
		this.target = this.pos.copy();
		this.vel = createVector(0,0);
		this.acc = createVector(0, 0);
		this.color = img.get(x, y);  //get the color of this particle from image
	}
	
	move() {
    //use color to divide the area of picture
    let blueValue=blue(this.color);
    let redValue=red(this.color);
    let greenValue=green(this.color);
    //use if to get the area of blue lake
    if((this.pos.x*70/81+38/81*img.height)>this.pos.y&&(redValue<100||blueValue>150)&&this.pos.y>img.height*0.19){
      let attraction = p5.Vector.sub(this.target, this.pos);
      attraction.mult(attForce);
      //make lake particle leave away from the boat to imitate that the boat whipped up waves
      //the reference of the use of tmpForce & attraction from https://openprocessing.org/sketch/1084140
      let tmpForce = p5.Vector.sub(createVector(boatX, boatY), this.pos).limit(5/700*img.height);
      let repulsion = tmpForce.copy().normalize().mult(-20/1024*img.height).sub(tmpForce);
      repulsion.mult(repForce);
      this.acc = p5.Vector.add(attraction, repulsion);
      this.vel.mult(0.97);
      this.vel.add(this.acc);
      this.vel.limit(3);
      this.pos.add(this.vel);
      //make sure the lake particle not too far from the lake
      if(this.pos.y<=img.height*0.19){
        this.pos.y=img.height*0.19+1;
      }
    }else if(this.pos.y<img.height*0.32&&redValue>120){
      //clear the sky part
      this.color[3]=0;
    }
    else if(this.pos.y<img.height*0.44&&redValue>180&&greenValue>120&&this.pos.y>img.height*0.32){
    //add random gradient of color to the stationary particles in the middle of the lake
      lakeMidRedAcc=random(-0.5,0.5);
      lakeMidRedAcc=random(-0.5,0.5);
    //make the change of color not too fast,add ease effect
      if(lakeMidRedAcc>=2){
        lakeMidRedAcc=2;
      }else if(lakeMidRedAcc<=-2){
        lakeMidRedAcc=-2;
      }
      if(lakeMidGreenAcc>=2){
        lakeMidGreenAcc=2;
      }else if(lakeMidGreenAcc<=-2){
        lakeMidGreenAcc=-2;
      }
      lakeMidRedVel=lakeMidRedVel+lakeMidRedAcc;
      lakeMidGreenVel=lakeMidGreenVel+lakeMidGreenAcc;
      if(lakeMidRedVel>=10){
        lakeMidRedVel=10;
      }else if(lakeMidRedVel<=-10){
        lakeMidRedVel=-10;
      }
      if(lakeMidGreenVel>=10){
        lakeMidGreenVel=10;
      }else if(lakeMidGreenVel<=-10){
        lakeMidGreenVel=-10;
      }
      //color[0] is red value of the pixel of the image, color[1] is green value of the pixel of the image, reference:https://p5js.org/reference/#/p5.Image/pixels
      this.color[0]+=lakeMidRedVel;
      this.color[1]+=lakeMidGreenVel;
      //set the margin of the color change, improve the fault tolerance rate
      if(this.color[0]>=255){
        this.color[0]=255;
        lakeMidRedVel=-5;
      }else if(this.color[0]<=180){
        this.color[0]=180;
        lakeMidRedVel=5;
      }
      if(this.color[1]>=255){
        this.color[1]=255;
        lakeMidGreenVel=-5;
      }else if(this.color[1]<=120){
        this.color[1]=120;
        lakeMidGreenVel=5;
      }
    }
	}
	display() {
    push();
    let blueValue=blue(this.color);
    let redValue=red(this.color);
    this.color[3]=150;
    stroke(this.color);
    let lakeSlope=0.5;
    let changeX=random(10,40)/810*img.width;
    if(this.pos.y>0.23*img.height&&(redValue<100||blueValue>150)){
      strokeWeight(random(5,10)/810*width);
      line(this.pos.x, this.pos.y,this.pos.x+changeX,this.pos.y+changeX*lakeSlope);
    }else if(this.pos.y>0.3*img.height){
      strokeWeight(random(5,20)/810*width);
      line(this.pos.x, this.pos.y,this.pos.x+changeX,this.pos.y+changeX*lakeSlope);
    }
    pop();
	}
}
