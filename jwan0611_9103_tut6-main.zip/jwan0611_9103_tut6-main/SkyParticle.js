class SkyParticle {
    constructor(x, y) {
      this.x = x; // The abscissa of the particle
      this.y = y; // The vertical coordinate of the particle
      // color of particles
      this.c = img.get(x, y);
      this.colorPri=img.get(x, y);
      this.first = true; // Is it the first particle
      this.initX = x; // initial abscissa
      this.initY = y; // Initial vertical coordinate
      this.frame = 0; // Current frame number
      if (sky_mode == 1) {
        // Choose the maximum number of frames according to the mode
        this.maxFrame = 400;
      } else {
        this.maxFrame = int(random(100, 500));
      }
    }
  
    draw() {
      noStroke();
      //random change the color of sky particle
      this.c[0]= skyColor1;
      this.c[1]= skyColor1;
      if(this.c[0]>255){
        this.c[0]=255;
      }else if (this.c[0]<150){
        this.c[0]=150;
      }
      if(this.c[1]>220){
        this.c[1]=220;
      }else if (this.c[1]<0){
        this.c[1]=0;
      }
      //make sure the color change is not too much 
      if((this.c[0]-this.colorPri[0]>=100)||(this.c[1]-this.colorPri[1]>=50)||(this.c[0]-this.colorPri[0]<=-100)||(this.c[1]-this.colorPri[1]<=-100))
      {
        this.c[0]=this.colorPri[0];
        this.c[1]=this.colorPri[1];
      }
       this.c[3]=50;
      fill(this.c); // Set the fill color of particles
      ellipse(this.x, this.y+random(-3,3)/1024, random(5,10)/810*img.width*sky_space, sky_space*random(2,4)/1024*img.height);
      
    }
  
    // update() {
    //   if (frameCount % 2 == 0) {
    //     // Update position every 2 frames
    //     let x = this.x * sky_noiseScale; // Calculate the noise value in the x direction
    //     let y = this.y * sky_noiseScale; // Calculate the noise value in the y direction
    //     // Set the noise value for the z-axis
    //     let z = 10000;
    //     this.x += noise(x, y, z) - 0.5; // Update x coordinate based on noise value
    //     z = 1;
    //     this.y += (noise(x, y, z) - 0.5) * 0.5; // Update y coordinate based on noise value
    //   }
  
    //   // Increased frame rate
    //   this.frame++;
    //   if (this.frame >= this.maxFrame) {
    //     // When the number of frames reaches the maximum number of frames, reset the particle position
    //     this.frame = 0; // Reset frame number to 0
    //     this.x = this.initX; // Reset x coordinate to initial value
    //     this.y = this.initY; // Reset x coordinate to initial value
    //   }
    // }
  }