class PersonParticle {
    constructor(pX, pY) {
      this.pos = createVector(pX, pY);
      this.vel = createVector(0, 0);
      this.acc = createVector(0, 0);
      this.color =pic.get(pX, pY);
      this.initialX = pX; // Store the initial horizontal position
      this.initialY = pY; // Store the initial vertical position
    }
    move() {
      //use color value to divide the man's body & face
      angleMode(DEGREES);
      let redValue = red(this.color);
      let blueValue = blue(this.color);
      let greenValue = green(this.color);
      if(blueValue <80 && redValue <100 && greenValue < 100){  
        this.vel.mult(0.97/810*img.width);
        this.vel.limit(3/810*img.width);
        this.vel.add(random(-0.01,0.01),0.3);
        let amplitude = width/30/810*img.width;  
        let frequency = 0.6/810*img.width;
        // to draw the body strok in a sin curve 
        this.pos.x = this.initialX + amplitude * sin(frequency * this.pos.y)-width/30/810*img.width;
        this.pos.add(this.vel);  
        //draw the body line
          push();
          fill( this.color); // Circle color
          noStroke();
          if(this.pos.y>0.63*img.height){
            ellipse(this.pos.x+42/810*img.width, this.pos.y-10/1024*img.height, 15/810*img.width, random(20,40)/1024*img.height); // Draw a circle based on particle's position
          }
          pop();
         
        //if the stroke goes beyond the convas, reset to the orginal position 
          if (this.pos.y>=img.height*0.9){
            this.pos.y = this.initialY; 
          }
        } 
  
        else 
        { // define the face area 
          this.pos.add(0,random(-1,1)/1024*img.height); 
          push();
          fill( this.color); // Circle color
          rotate(PI/4.0);
          noStroke();
          let translateX = 0;
          let translateY = sin(frameCount) * 10/1024*img.height;
          translate(translateX, translateY);
          if(this.pos.y<0.7*img.height){
            ellipse(this.pos.x, this.pos.y, random(20,30)/810*img.width, 30/1024*img.height); // Draw a circle based on particle's position
          }
          pop();
        } 
    } 
  }