let img;
let canvasSize=1;
let attForce = 0.01;
let repForce = 0.01;

let particles = [];
let personParticles=[];
let numParticle = 500;
let numSegments=100;
let boatX;
let boatY;
let boatDir;
let boatVel;
let boatAcc;
let bridgeVel;
let bridgeAcc;
let lakeMidRedVel;
let lakeMidRedAcc;
let lakeMidGreenVel;
let lakeMidGreenAcc;

let slope;
let intercept;
let legStatus;
// Define variables for the starting point and end points of the line segments
let originX;
let originY;
let line1EndX;
let line1EndY;
let line2EndX;
let line2EndY;
let angle1;
let angle2;
let lineWidth;
let numLines;
let personCount

//define variables for the sound effect
let spectrum;
let skyColor1;
let particle_h;


let sky_particles = [];
// Set the noise ratio of sky particles
let sky_noiseScale = 0.01;
// Set the spacing between sky particles
let sky_space = 5;
// Set the mode of sky particles
let sky_mode = 1;
// Set the height of sky particles
let sky_height;


function preload() {
	img = loadImage('assests/Scream1.jpg');
  pic = loadImage('assests/The_Scream_Figure.png');
  audio = loadSound('assests/Rite of Spring.mp3');
}

function setup() {
  imageResize();
	strokeWeight(5/500*img.width);//the size of ever particle
	background(0);//black background
  lakeSetup();
  sky_height=img.height*0.32;
  skySetup();
	boatVel = createVector(0, 0);
  boatAcc = createVector(0, 0);
  bridgeSetup();
  fft = new p5.FFT();
// Add the song (sample) into the FFT's input
  audio.connect(fft);
 
}

function draw() {
  easing();
  
	//update the position of each particle each frame
	for (let p of particles) {
		p.move();
		p.display();
	}
  //draw boat
  boat(boatX,boatY);
  drawBridgePeople();

  spectrum = fft.analyze(); // music analysis
  for (let i = 0; i < spectrum.length; i++) {
    // map the spectrum to particles size of different areas
   particle_h = map(spectrum[i], 0, 255, 10, 40); 
    // map the spectrum to the sky color 
   skyColor1 = map(log(i), 0, log(spectrum.length), 0, 255); 
    //draw sky
   skyDraw();
}
 
}

function windowResized() {
  imageResize();
  sky_height=img.height*0.32;
  skyReSetup();
  //clear the canvas
   particles = [];
   personParticles = [];
  //redraw the particle
  lakeSetup();
  boatRestart()
  bridgeSetup();
}

function lakeSetup(){
  let segmentWidth = img.width / numSegments;
  let segmentHeight = img.height / numSegments;
//use for loop to get every segment color of img and use particles array to store them, reference:https://canvas.sydney.edu.au/courses/53019/pages/week-7-tutorial?module_item_id=2098597
  for (let segYPos=0; segYPos<img.height; segYPos+=segmentHeight) {
    //this is looping over the height
    for (let segXPos=0; segXPos<img.width; segXPos+=segmentWidth) {
      //this loops over width
      //This will create a segment for each x and y position
      let pX=segXPos;
      let pY=segYPos;
      particles.push(new Particle(pX,pY)); //push to the lake particles
      personParticles.push(new PersonParticle(pX,pY)); 
    }
  }
  //randomly create a new boat
  boatX=random(img.width);
  boatY=random(0.5*img.height);
  boatDir=0;
  //make sure the position of boat is in the lake
  if((boatX*40/81+30/81*img.height)<boatY){
    boatY=boatX*40/81+30/81*img.height-2/81*img.height;
  }
  else if(boatY<28/81*img.height){
    boatY=28/81*img.height+2/81*img.height;
  }
}
function imageResize(){
  if((windowWidth/windowHeight)>(810/1024)){
    createCanvas(windowHeight/1024*810, windowHeight);
    img.resize(windowHeight/1024*810, windowHeight);
    pic.resize(windowHeight/1024*810, windowHeight);

  }else{
    createCanvas(windowWidth, windowWidth/810*1024);
    img.resize(windowWidth, windowWidth/810*1024);
    pic.resize(windowWidth, windowWidth/810*1024);

  }
}
function boatRestart(){
   //raddom create a new boat
   boatX=random(img.width);
   boatY=random(0.5*img.height);
   boatDir=0;
   //make sure the position of boat is in the lake
   if((boatX*40/81+30/81*img.height)<boatY){
     boatY=boatX*40/81+30/81*img.height-2/81*img.height;
   }
   else if(boatY<28/81*img.height){
     boatY=28/81*img.height+2/81*img.height;
    }
}
function bridgeSetup(){
  bridgeVel=createVector(79/81, 1);
  bridgeAcc=createVector(0, 0);

  lakeMidRedVel=1;
  lakeMidRedAcc=0;
  lakeMidGreenVel=1;
  lakeMidGreenAcc=0;

//bridge&2 small people
  slope = (600 - 380) / (100 - 0);
  intercept = 380/1024*img.height;
  personCount=0;
  legStatus=0;
}
function drawBridgePeople(){
  //bridge&2 people
  originX = 0;
  originY = 380/1024*img.height;
  line1EndX = img.width;
  line1EndY = 870/1024*img.height;
  line2EndX = 0;
  line2EndY = img.height;
  angle1 = atan2(line1EndY - originY, line1EndX - originX);
  angle2 = atan2(line2EndY - originY, line2EndX - originX);
  
  lineWidth = 8/810*img.width;  // Set the line width for the random lines
  numLines = 600;  // Set the number of random lines to draw
  push();
  strokeWeight(lineWidth); 
  drawRandomLines(originX, originY, angle1, angle2, numLines); 

  // Calculate the x based on frameCount and the corresponding y
  //let x = (frameCount % 100);
  let personX = (personCount % 100);
  let personY = slope * personX + intercept;
  
  // Draw the people, positions change over time with the frameCount
  drawPeople(personX, personY);
  pop();
// front person
  for (let p of personParticles) {
    p.move();
  }
  // draw the eyes and mouth area
  drawEyesMouth();
}
function easing(){
  //Draw a black rectangle with an opacity of 20 to create the trail effect on each frame
	fill(0, 10);
	noStroke();
	rect(0, sky_height, img.width, img.height);
  //ease of sky
  push();
  fill(233,197,111,1);
  rect(0,0,img.width,sky_height);
  pop();
  //ease of boat
  push();
  fill(0,20);
  rect(boatX-10,boatY-10,20,20);
  pop();
}


function boat(x,y){
  let bX=x;
  let bY=y;
  //use semicircle, rectangle, line to form a boat
  push();
  fill(255);
  stroke(255);
  strokeWeight(1);
  arc(bX,bY,20,8,0*PI,1*PI,OPEN);
  line(bX,bY,bX,bY-7);
  noStroke();
  fill(255,255,255);
  rect(bX,bY-7,5,2);
  pop();
  //make sure boat move in the blue lake
  if((boatX*30/81+29/81*img.height)<boatY){
    //boatAcc.y=-0.2;
    boatY=boatY-2/1024*img.height;
    boatVel.sub(0,1/1024*img.height);
  }
  else if(boatY<270/810*img.height){
    boatY=boatY+2/810*img.height;
    boatVel.add(0,1/1024*img.height);
  }else{
    // make boat move randomly, and add ease effect
    boatAcc.add(random(-0.1,0.1),random(-0.1,0.1));
    boatAcc.limit(0.5/810*img.width,0.5/810*img.width);
    boatVel.add(boatAcc);
    boatVel.limit(2/810*img.width,2/810*img.width);//make sure the speed of the boat not too fast
    boatX=boatX+boatVel.x;
    boatY=boatY+boatVel.y;
  if(boatX>=img.width){
    boatRestart()
  }else if(boatX<=0){
    boatRestart()
  }}
}

//sky
function skySetup() {
  img.loadPixels();
  for (let x = 0; x < img.width; x += sky_space) {
    // Traverse the canvas width and step based on the spacing between sky particles
    for (let y = 0; y < sky_height; y += sky_space) {
      // Traverse the height of the sky particles and step based on the spacing between the sky particles
      // Create a sky particle object
      let particle = new SkyParticle(x, y);
      // Add the sky particle object to the array
      sky_particles.push(particle);
    }
  }
  push();
  //sky background
  fill(233,197,111);
  rect(0,0,img.width,sky_height);
  pop();
}
function skyReSetup() {
//clear the primary sky particle
  sky_particles = [];
  img.loadPixels();
//redraw the particle
  for (let x = 0; x < img.width; x += sky_space) {
    // Traverse the canvas width and step based on the spacing between sky particles
    for (let y = 0; y < sky_height; y += sky_space) {
      // Traverse the height of the sky particles and step based on the spacing between the sky particles
      // Create a sky particle object
      let particle = new SkyParticle(x, y);
      // Add the sky particle object to the array
      sky_particles.push(particle);
    }
  }
}
function skyDraw() {
  for (let p of sky_particles) {
    // Traverse sky particle array
    // p.update();
    p.draw();
  }
}

function drawRandomLines(originX, originY, angle1, angle2, numLines) {

  for (let i = 0; i < numLines; i++) {  // Loop through the specified number of lines
    let angle = random(angle1, angle2); 
    let length = random(20/1024*img.height, 1500/1024*img.height); 

    // Calculate the end point of the line using trigonometry
    let endX = originX + length * cos(angle);
    let endY = originY + length * sin(angle);
    
    lineSegment(originX, originY, endX, endY);  // Draw the line segment
  }
}

function lineSegment(x1, y1, x2, y2) {

  let d = dist(x1, y1, x2, y2); // Calculate the distance between the start and end points of the line

  let start = 0; 

  // Continue drawing line segments until the full line is drawn
  while (start < d) { 

    let segLength = random(10/1024*img.height, 20/1024*img.height); 
    
    // Calculate the interpolation ratios for segment start and end points
    let a = start / d;
    let b = (start + segLength) / d;
    
    // Interpolate to find the start and end points of the segment
    let startX = lerp(x1, x2, a);
    let startY = lerp(y1, y2, a);
    let endX = lerp(x1, x2, b);
    let endY = lerp(y1, y2, b);

    // Calculate the midpoint X,Y coordinate for color sampling
    let midX = (startX + endX) / 2; 
    let midY = (startY + endY) / 2; 
    // Sample the color from the background image at the midpoint and set opacity
    let col = img.get(midX, midY);
    col[3] = 150; 
    stroke(col); 
    line(startX, startY, endX, endY);
    // Increment the start position for the next segment
    start += segLength; 
  }
}

function drawPeople(x, y) {
  // Scale between 0.8 and 2 as y goes from 380 to 600
  let scaleFactor = map(y, 300/1024*img.height, 1800/1024*img.height, 1/810*img.height, 20/810*img.height); 
  push();
  translate(x, y);  // Translate to the position where the people will be drawn
  scale(scaleFactor);  // Apply the scaling
  noStroke();
  // Set fill color and draw ellipses for the first person
  fill(108, 92, 59);
  ellipse(0, -30/1024*img.height, 10/810*img.width, 12/1024*img.height);
  ellipse(0, -5/1024*img.height, 20/810*img.width, 45/1024*img.height);
  //draw legs and make it move
  stroke(108, 92, 59);
  strokeWeight(2/810*img.width);
  if(legStatus==0){
    //Make the legs longer in front and shorter in back, according to the principle of nearly big, round and small
    line(-2/810*img.width,17/1024*img.height,-2/810*img.width,35/1024*img.height);
    line(2/810*img.width,17/1024*img.height,2/810*img.width,39/1024*img.height);
    stroke(48, 58, 68);
    line(8/810*img.width,33/1024*img.height,8/810*img.width,50/1024*img.height);
    line(12/810*img.width,33/1024*img.height,12/810*img.width,54/1024*img.height);
    legStatus++;
  }else{
    line(-2/810*img.width,17/1024*img.height,-5/810*img.width,35/1024*img.height);
    line(2/810*img.width,17/1024*img.height,5/810*img.width,39/1024*img.height);
    stroke(48, 58, 68);
    line(8/810*img.width,33/1024*img.height,5/810*img.width,50/1024*img.height);
    line(12/810*img.width,33/1024*img.height,15/810*img.width,54/1024*img.height);
    legStatus=0;
  }
  noStroke();
  // Set a different fill color and draw ellipses for the second person
  fill(48, 58, 68);
  ellipse(10/810*img.width, -10/1024*img.height, 10/810*img.width, 12/1024*img.height);
  ellipse(10/810*img.width, 15/1024*img.height, 20/810*img.width, 45/1024*img.height);
  pop();
  personCount++;
  if(personCount>400){
    personCount=0;
  }
}

//draw the changed eyes & mouth of the front person 
function drawEyesMouth(){
  push(); 
  fill(55,60,50);
  noStroke();
  let eyeheight=particle_h;
  ellipse (img.width*355/810,img.height* 555/1024,30/810*img.width,eyeheight);
  ellipse (img.width*410/810,img.height* 555/1024,30/810*img.width,eyeheight);
  ellipse (img.width*380/810,img.height* 620/1024,20/810*img.width,eyeheight);
  pop();
}

// press the button to play and stop the music 
function mousePressed() {
  if (audio.isPlaying()) {
  audio.stop();
  console.log("stop"); //show text when the music stops 
  } else {
  audio.play();
  console.log("playing"); //show text when the music starts 
  }
}

